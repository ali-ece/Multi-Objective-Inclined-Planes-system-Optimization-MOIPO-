
function f=Cost(x)

    n=numel(x);
    
    f=[0 0];

    f(1)=sum(-10*exp(-0.2*sqrt(x(1:n-1).^2+x(2:n).^2)));
    f(2)=sum(abs(x).^0.8+5*sin(x.^3));
    
end