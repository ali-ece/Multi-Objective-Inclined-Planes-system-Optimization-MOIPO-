%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MATLAB Code for   (MOIPO)                                         %        
%                                                                    %        
%   Programmed By: najmeh sayyadi                                    %                             %
%   e-Mail: sayyadinajmeh@yahoo.com                                  %                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ball=CreateEmptyball(n)
    if nargin<1
        n=1;
    end

    empty_ball.Position=[];
    empty_ball.Velocity=[];
    empty_ball.Acceleration=[];
    empty_ball.Acceleration1=[];
    empty_ball.Acceleration2=[];
    empty_ball.Cost=[];
    empty_ball.Dominated=false;
    empty_ball.Best.Position=[];
    empty_ball.Best.Cost=[];
    empty_ball.GridIndex=[];
    empty_ball.GridSubIndex=[];
    
    ball=repmat(empty_ball,n,1);
    
end