%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MATLAB Code for   (MOIPO)                                         %        
%                                                                    %        
%   Programmed By: najmeh sayyadi                                    %                             %
%   e-Mail: sayyadinajmeh@yahoo.com                                  %                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear;
close all;

%% Problem Definition
        CostFunction=@Cost;
        nVar=3;
        VarMin=-5;
        VarMax=5;
        MaxIt=500;

VarSize=[1 nVar];

VelMax=(VarMax-VarMin)/10;

%% MOIPO Settings

nPop=100;   % Population Size

nRep=100;   % Repository Size



 %testfunc1       
 %         c1 = 0.7184;
 %         c2 = 2.7613;
 %         shift1 = 72.4684;
 %         shift2 = 188.5077;
 %         scale1 = 0.035;
  %        scale2 = 0.8245;
        
%testfunc2
         c1 = 0.2248273331;
          c2 = 2.2829730221;
          shift1 = 121.0439751601;
         shift2 = 149.6747546522;
         scale1 = 0.0558110177;
          scale2 = 0.5248145911;
        
%testfunc3
         % c1 = 0.247206821;
         %c2 = 2.3524491126;
         %shift1 = 198.4520868367;
         %shift2 = 361.2375086854;
         % scale1 = 0.0124278826;
         % scale2 = 0.0224392667;
         
%testfunc4
%         c1 = 0.9283;
       % c2 = 0.2399;
       %  shift1 = 260.077;
       % shift2 = 81.4612;
        %  scale1 = 0.0183;
         %scale2 = 0.0307;

%testfunc5
   %     c1 = 0.3893179174;
   %      c2 = 2.9512227061;
  %      shift1 = 534.5566231873;
  %        shift2 = 367.0491333246;
 %         scale1 = 0.1452857433;
 %         scale2 = 0.900190043;
       
%testfunc9
    %     c1 = 0.1024;
    %     c2 = 3.6577;
   %      shift1 = 300;
   %      shift2 = 300;
   %      scale1 = 0.035;
  %       scale2 = 0.035;

%testfunc12
 %          c1 = 0.3748;
 %          c2 = 2.4771;
 %          shift1 =654;
 %          shift2 =687;
%           scale1 =0.0319;
%           scale2 =0.1142;
        
%testfunc13
 %            c1 = 0.4457588092;
%             c2 = 2.6128227908;
%             shift2 = 602.8512489222;
%             scale1 = 0.0386207254;
%             scale2 = 0.0463913141;
        
% %testfunc14
          % c1 = 0.6067109875;
           %c2 = 0.5513162156;
          % shift1 = 424.2936079461;
          % shift2 = 203.6016969817;
          % scale1 = 0.6053868306;
          % scale2 = 0.2927474231;
          
%testfunc15
 %       c1 = 0.2;
 %         c2 = 0.3750094787;
 %         shift1 = 1.2724782229;
 %         shift2 = 332.671693694;
 %         scale1 = 0.0094604492;
 %         scale2 = 0.0034484863;
        

alpha=0.1; 

nGrid=10;  

beta=4;     

gamma=2;   

%% Initialization

ball=CreateEmptyball(nPop);

for i=1:nPop
   
    ball(i).Position=unifrnd(VarMin,VarMax,VarSize);
    ball(i).Velocity=zeros(VarSize);
    ball(i).Acceleration=zeros(VarSize);
    ball(i).Acceleration1=zeros(VarSize);
    ball(i).Acceleration2=zeros(VarSize);
    
    ball(i).Cost=CostFunction(ball(i).Position);
    ball(i).Best.Cost=ball(i).Cost;
end

ball=DetermineDomination(ball);
rep=GetNonDominatedParticles(ball); 
rep_costs=GetCosts(rep);
G=CreateHypercubes(rep_costs,nGrid,alpha);
     
for i=1:numel(rep)
    [rep(i).GridIndex , rep(i).GridSubIndex]=GetGridIndex(rep(i),G);
end
    
%% MOIPO Main Loop

for it=1:MaxIt
    for i=1:nPop
        rep_h=SelectLeader(rep,beta);
        for j=1:nPop
    
     
            df1=ball(j).Cost(1)-ball(i).Cost(1);
            df2=ball(j).Cost(2)-ball(i).Cost(2);
     
          if df1<0      
             ball(i).Acceleration1=ball(i).Acceleration1...
            +sin(atan(df1./(ball(i).Position-ball(j).Position)));
          end
          
         if df2<0 
           ball(i).Acceleration2=ball(i).Acceleration2...
           +sin(atan(df2./(ball(i).Position-ball(j).Position)));
         end
         
         ball(i).Acceleration=.5*(ball(i).Acceleration1+ ball(i).Acceleration2);
          
       end
    

        
    k1 = c1 ./ (1 + exp((it - shift1) .* scale1));
    k2 = c2 ./ (1 + exp(-(it - shift2) .* scale2));
    
    %update velocity
    ball(i).Velocity=rep_h.Position-ball(i).Position;
    

    
    %update position
    ball(i).Position=ball(i).Position+k1.*rand(VarSize)...
        .*ball(i).Acceleration+k2.*rand(VarSize).*ball(i).Velocity;
       
        ball(i).Position=min(max(ball(i).Position,VarMin),VarMax);
        
        ball(i).Cost=CostFunction(ball(i).Position);

      
    end
    
    ball=DetermineDomination(ball);
    nd_particle=GetNonDominatedParticles(ball);
    
    rep=[rep
         nd_particle];
    rep=DetermineDomination(rep);
    rep=GetNonDominatedParticles(rep);
    
    for i=1:numel(rep)
        [rep(i).GridIndex ,rep(i).GridSubIndex]=GetGridIndex(rep(i),G);
    end
    
    if numel(rep)>nRep
        EXTRA=numel(rep)-nRep;
        rep=DeleteFromRep(rep,EXTRA,gamma);
        
        rep_costs=GetCosts(rep);
        G=CreateHypercubes(rep_costs,nGrid,alpha);
        
    end
   
    disp(['Iteration ' num2str(it) ': Number of Repository Particles = ' num2str(numel(rep))]);
    

end

%% Results

costs=GetCosts(ball);
rep_costs=GetCosts(rep);

figure;

plot(costs(1,:),costs(2,:),'b.');
hold on;
plot(rep_costs(1,:),rep_costs(2,:),'rx');
legend('Main Population','Repository');
title('MOIPO');
xlabel('f1');
ylabel('f2');

